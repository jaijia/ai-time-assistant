import os
import sqlite3
from typing import Any, Dict, List


DB_PATH = os.path.join(os.path.dirname(__file__), "schedule.db")


def _get_connection() -> sqlite3.Connection:
    """Create a SQLite connection with row access by name-like keys."""
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db() -> None:
    """Initialize the SQLite database and create the tasks table if it doesn't exist."""
    with _get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            # Exact schema as specified
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_name TEXT NOT NULL,
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                priority TEXT DEFAULT '中',
                status TEXT DEFAULT '待办'
            );
            """
        )
        connection.commit()


def add_task(task_data: Dict[str, Any]) -> int:
    """Add a new task to the database.

    Args:
        task_data: Dictionary containing keys: task_name, start_time, end_time, priority (optional), status (optional)

    Returns:
        The newly created task id.
    """
    required_fields = ["task_name", "start_time", "end_time"]
    for field in required_fields:
        if field not in task_data or task_data[field] is None:
            raise ValueError(f"Missing required field: {field}")

    priority = task_data.get("priority", "中")
    status = task_data.get("status", "待办")

    with _get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            INSERT INTO tasks (task_name, start_time, end_time, priority, status)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                task_data["task_name"],
                task_data["start_time"],
                task_data["end_time"],
                priority,
                status,
            ),
        )
        connection.commit()
        return cursor.lastrowid


def get_all_tasks() -> List[Dict[str, Any]]:
    """Fetch all tasks ordered by start_time as a list of dictionaries."""
    with _get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute(
            """
            SELECT id, task_name, start_time, end_time, priority, status
            FROM tasks
            ORDER BY start_time ASC
            """
        )
        rows = cursor.fetchall()
        return [dict(row) for row in rows]


def delete_task(task_id: int) -> None:
    """Delete a task by its ID."""
    with _get_connection() as connection:
        cursor = connection.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        connection.commit()


# Ensure database is initialized if this module is imported and DB doesn't exist yet
if not os.path.exists(DB_PATH):
    init_db()