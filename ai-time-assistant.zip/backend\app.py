import json
import os
from typing import Any, Dict, List

from flask import Flask, jsonify, request
from flask_cors import CORS
from openai import OpenAI
from dotenv import load_dotenv

try:
    # When running as a package: python -m backend.app
    from .database import init_db, get_all_tasks, add_task, delete_task
except ImportError:
    # When running the file directly: python backend/app.py
    from database import init_db, get_all_tasks, add_task, delete_task

# Load environment variables from .env (if present)
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))


app = Flask(__name__)
CORS(app)  # Enable CORS for all routes; adjust origins in production


# Ensure DB exists
init_db()


# Exact prompt template as specified
PROMPT_TEMPLATE = """
You are a world-class personal assistant and time management expert. Your goal is to help me efficiently plan my schedule.

# My Current Schedule
Here is my list of currently scheduled tasks in JSON format:
{current_schedule}

# My New Request
Here is the new task or idea I just mentioned:
"{user_input}"

# Your Mission
Execute the following steps:
1.  **Parse New Tasks**: From my "New Request", extract all concrete tasks and format them as a JSON list. Each task must have "task_name", "start_time", "end_time", and "priority".
2.  **Analyze Schedule**: Review my "Current Schedule" combined with the newly parsed tasks. Identify any time conflicts, overly packed schedules, or potential optimizations.
3.  **Provide Advice**: Based on your analysis, give me 1-3 actionable pieces of advice in a friendly, professional tone.
4.  **Final Output**: Structure your entire response as a single JSON object with the following format:
    {{
      "new_tasks": [{{...parsed new tasks...}}],
      "advice": "The planning advice text goes here..."
    }}

Strictly adhere to this final output format.
"""


def call_deepseek_api(prompt: str) -> Dict[str, Any]:
    """Call DeepSeek API using OpenAI client and return parsed JSON as per the template's final output."""
    api_key = os.environ.get("DEEPSEEK_API_KEY")
    if not api_key:
        # Provide a clear error if key is missing
        raise RuntimeError("DEEPSEEK_API_KEY is not set in environment variables")

    # Initialize OpenAI client with DeepSeek base URL
    client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")

    try:
        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            stream=False
        )

        # Extract the assistant message text
        message_text = response.choices[0].message.content

        # The model is instructed to return a single JSON object; parse it.
        try:
            parsed = json.loads(message_text)
            if not isinstance(parsed, dict):
                raise ValueError("DeepSeek response is not a JSON object")
            # Ensure required keys exist
            parsed.setdefault("new_tasks", [])
            parsed.setdefault("advice", "")
            return parsed
        except json.JSONDecodeError as exc:
            # If the model returns extra prose, try to extract a JSON object substring
            # as a fallback. This is a best-effort heuristic.
            text = message_text
            start = text.find("{")
            end = text.rfind("}")
            if start != -1 and end != -1 and end > start:
                json_sub = text[start : end + 1]
                parsed = json.loads(json_sub)
                parsed.setdefault("new_tasks", [])
                parsed.setdefault("advice", "")
                return parsed
            raise ValueError(f"Failed to parse DeepSeek JSON response: {exc}")
    
    except Exception as exc:
        raise RuntimeError(f"DeepSeek API call failed: {exc}")


@app.get("/api/tasks")
def api_get_tasks():
    """Return all tasks as JSON for the frontend schedule table."""
    tasks = get_all_tasks()
    return jsonify(tasks)


@app.post("/api/tasks")
def api_post_tasks():
    """Accept user input, call DeepSeek, persist new tasks, and return advice.

    Expected input JSON: { "text": "user input here" }
    """
    payload = request.get_json(silent=True) or {}
    user_text = (payload.get("text") or "").strip()
    if not user_text:
        return jsonify({"error": "Missing 'text' in request body"}), 400

    # Fetch current schedule and format prompt
    current_schedule = get_all_tasks()
    prompt = PROMPT_TEMPLATE.format(
        current_schedule=json.dumps(current_schedule, ensure_ascii=False, indent=2),
        user_input=user_text,
    )

    # Call DeepSeek to get planning advice and new tasks
    ai_result = call_deepseek_api(prompt)
    new_tasks: List[Dict[str, Any]] = ai_result.get("new_tasks", [])
    advice: str = ai_result.get("advice", "")

    # Persist newly suggested tasks
    for task in new_tasks:
        # Normalize keys and apply defaults if missing
        normalized = {
            "task_name": task.get("task_name") or task.get("name") or "未命名任务",
            "start_time": task.get("start_time") or "",
            "end_time": task.get("end_time") or "",
            "priority": task.get("priority") or "中",
        }
        # Validate minimal fields
        if not normalized["start_time"] or not normalized["end_time"]:
            # Skip invalid tasks rather than failing the whole request
            continue
        add_task(normalized)

    # Return the AI advice and the tasks it proposed (as echoed back)
    return jsonify({
        "advice": advice,
        "new_tasks": new_tasks,
    })


@app.delete("/api/tasks")
def api_clear_all_tasks():
    """Clear all tasks from the database."""
    try:
        import sqlite3
        db_path = os.path.join(os.path.dirname(__file__), "schedule.db")
        with sqlite3.connect(db_path) as conn:
            conn.execute("DELETE FROM tasks")
            conn.commit()
        return jsonify({"message": "All tasks cleared successfully"})
    except Exception as e:
        return jsonify({"error": f"Failed to clear tasks: {str(e)}"}), 500


@app.delete("/api/tasks/<int:task_id>")
def api_delete_task(task_id):
    """Delete a specific task by ID."""
    try:
        delete_task(task_id)
        return jsonify({"message": "Task deleted successfully"})
    except Exception as e:
        return jsonify({"error": f"Failed to delete task: {str(e)}"}), 500


@app.patch("/api/tasks/<int:task_id>")
def api_update_task(task_id):
    """Update a specific task by ID."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400
        
        # Update task in database
        import sqlite3
        db_path = os.path.join(os.path.dirname(__file__), "schedule.db")
        with sqlite3.connect(db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build update query dynamically based on provided fields
            update_fields = []
            values = []
            
            if 'status' in data:
                update_fields.append("status = ?")
                values.append(data['status'])
            
            if 'task_name' in data:
                update_fields.append("task_name = ?")
                values.append(data['task_name'])
            
            if 'start_time' in data:
                update_fields.append("start_time = ?")
                values.append(data['start_time'])
            
            if 'end_time' in data:
                update_fields.append("end_time = ?")
                values.append(data['end_time'])
            
            if 'priority' in data:
                update_fields.append("priority = ?")
                values.append(data['priority'])
            
            if not update_fields:
                return jsonify({"error": "No valid fields to update"}), 400
            
            values.append(task_id)
            query = f"UPDATE tasks SET {', '.join(update_fields)} WHERE id = ?"
            cursor.execute(query, values)
            conn.commit()
            
            if cursor.rowcount == 0:
                return jsonify({"error": "Task not found"}), 404
        
        return jsonify({"message": "Task updated successfully"})
    except Exception as e:
        return jsonify({"error": f"Failed to update task: {str(e)}"}), 500


@app.get("/")
def root():
    """Return a friendly message to indicate the backend is running."""
    return jsonify({"status": "ok", "message": "AI Time Assistant backend is running.", "endpoints": ["/api/tasks", "/health"]})


@app.get("/health")
def health():
    """Health check endpoint for monitoring or quick checks."""
    return jsonify({"status": "healthy"})


if __name__ == "__main__":
    # Run the Flask app for local development
    app.run(host="127.0.0.1", port=5000, debug=True)