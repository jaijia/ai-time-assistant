// Frontend logic for interacting with the Flask backend API

const API_BASE = 'http://127.0.0.1:5000';

// Update status bar information
function updateStatusBar(tasks = []) {
  const taskCountEl = document.getElementById('task-count');
  const lastUpdateEl = document.getElementById('last-update');
  const aiStatusEl = document.getElementById('ai-status');
  
  if (taskCountEl) {
    taskCountEl.textContent = `📋 当前任务: ${tasks.length} 个`;
  }
  
  if (lastUpdateEl) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    lastUpdateEl.textContent = `🕒 最后更新: ${timeStr}`;
  }
  
  if (aiStatusEl) {
    aiStatusEl.textContent = '🤖 AI 状态: 就绪';
  }
}

// Check if a task is expired based on current time
function isTaskExpired(task) {
  if (!task.start_time) return false;
  
  const now = new Date();
  const currentTime = now.getTime();
  
  try {
    // Parse different time formats
    let taskTime;
    
    // Handle "今天" or "今日" keywords
    if (task.start_time.includes('今天') || task.start_time.includes('今日')) {
      // Extract time from the string
      const timeMatch = task.start_time.match(/(\d{1,2})[点:](\d{0,2})/);
      if (timeMatch) {
        const hour = parseInt(timeMatch[1]);
        const minute = parseInt(timeMatch[2] || '0');
        taskTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute);
      } else {
        return false; // Can't parse time
      }
    } 
    // Handle pure time format like "07:00", "7:30", "14:30"
    else if (task.start_time.match(/^\d{1,2}:\d{2}$/)) {
      const timeMatch = task.start_time.match(/(\d{1,2}):(\d{2})/);
      if (timeMatch) {
        const hour = parseInt(timeMatch[1]);
        const minute = parseInt(timeMatch[2]);
        taskTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute);
      } else {
        return false;
      }
    }
    // Handle time format like "07:00-08:00" (extract start time)
    else if (task.start_time.includes('-')) {
      const startTime = task.start_time.split('-')[0].trim();
      const timeMatch = startTime.match(/(\d{1,2}):(\d{2})/);
      if (timeMatch) {
        const hour = parseInt(timeMatch[1]);
        const minute = parseInt(timeMatch[2]);
        taskTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hour, minute);
      } else {
        return false;
      }
    }
    else {
      // Try to parse as standard date
      taskTime = new Date(task.start_time);
      if (isNaN(taskTime.getTime())) {
        return false; // Can't parse date
      }
    }
    
    // Check if task time has passed
    return taskTime.getTime() < currentTime;
  } catch (e) {
    return false; // If parsing fails, don't mark as expired
  }
}

// Update statistics
function updateStats(tasks = []) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.status === '已完成').length;
  
  // Update stat elements
  document.getElementById('total-tasks').textContent = totalTasks;
  document.getElementById('completed-tasks').textContent = completedTasks;
}

// Fetch tasks and render them into the table
async function fetchAndDisplayTasks() {
  const tbody = document.querySelector('#schedule-table tbody');
  if (!tbody) return;
  tbody.innerHTML = '';

  try {
    const res = await fetch(`${API_BASE}/api/tasks`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const tasks = await res.json();

    tasks.forEach(task => {
      const tr = document.createElement('tr');
      const tdName = document.createElement('td');
      const tdStart = document.createElement('td');
      const tdEnd = document.createElement('td');
      const tdPriority = document.createElement('td');
      const tdCompletion = document.createElement('td');
      const tdActions = document.createElement('td');

      // Check if task is expired
      const isExpired = isTaskExpired(task);
      
      // Apply expired styling
      if (isExpired) {
        tr.classList.add('expired-task');
      }

      tdName.textContent = task.task_name || '';
      tdStart.textContent = task.start_time || '';
      tdEnd.textContent = task.end_time || '';
      tdPriority.textContent = task.priority || '';

      // Add completion checkbox
      const completionCheckbox = document.createElement('input');
      completionCheckbox.type = 'checkbox';
      completionCheckbox.className = 'completion-checkbox';
      completionCheckbox.checked = task.status === '已完成';
      completionCheckbox.title = '点击切换完成状态';
      completionCheckbox.addEventListener('change', () => toggleTaskCompletion(task.id, completionCheckbox.checked));
      
      tdCompletion.appendChild(completionCheckbox);
      tdCompletion.style.textAlign = 'center';

      // Add delete button
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = '🗑️';
      deleteBtn.className = 'delete-btn';
      deleteBtn.title = '删除任务';
      deleteBtn.addEventListener('click', () => deleteTask(task.id));
      
      tdActions.appendChild(deleteBtn);
      tdActions.style.textAlign = 'center';

      tr.appendChild(tdName);
      tr.appendChild(tdStart);
      tr.appendChild(tdEnd);
      tr.appendChild(tdPriority);
      tr.appendChild(tdCompletion);
      tr.appendChild(tdActions);
      tbody.appendChild(tr);
    });
    
    // Update status bar and stats with task count
    updateStatusBar(tasks);
    updateStats(tasks);
  } catch (err) {
    console.error('Failed to fetch tasks:', err);
    updateStatusBar([]);
    updateStats([]);
  }
}

// Send user's text to backend, display AI advice, and refresh tasks
async function submitToAI() {
  const textarea = document.getElementById('user-input');
  const loading = document.getElementById('loading');
  const adviceBox = document.getElementById('ai-advice');
  const text = (textarea?.value || '').trim();
  if (!text) {
    adviceBox.textContent = '请输入任务或想法后再提交。';
    return;
  }

  try {
    loading.hidden = false;
    adviceBox.textContent = '';
    
    // Update AI status
    const aiStatusEl = document.getElementById('ai-status');
    if (aiStatusEl) {
      aiStatusEl.textContent = '🤖 AI 状态: 思考中...';
    }

    const res = await fetch(`${API_BASE}/api/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(errText || `HTTP ${res.status}`);
    }

    const data = await res.json();
    // data should contain { advice, new_tasks }
    adviceBox.textContent = data.advice || 'AI 未返回建议。';

    // Refresh the schedule table
    await fetchAndDisplayTasks();
    
    // Update AI status to ready
    if (aiStatusEl) {
      aiStatusEl.textContent = '🤖 AI 状态: 就绪';
    }
  } catch (err) {
    console.error('Failed to submit to AI:', err);
    const adviceBox = document.getElementById('ai-advice');
    adviceBox.textContent = '提交失败，请稍后再试。';
    
    // Update AI status to error
    const aiStatusEl = document.getElementById('ai-status');
    if (aiStatusEl) {
      aiStatusEl.textContent = '🤖 AI 状态: 错误';
    }
  } finally {
    loading.hidden = true;
  }
}

// Quick action templates
const quickTemplates = {
  morning: "早上7点起床，7:30-8:00吃早餐，8:00-9:00阅读或学习，9:00-9:30运动",
  work: "上午9:00-12:00专注工作，下午2:00-5:00会议和协作，5:00-6:00总结和规划",
  study: "晚上7:00-8:30学习新技能，8:30-9:00复习笔记，9:00-9:30整理学习资料",
  exercise: "下午6:00-7:00健身房锻炼，7:00-7:30拉伸放松，7:30-8:00洗澡",
  evening: "晚上9:00-9:30回顾今日完成情况，9:30-10:00规划明日任务，10:00-10:30放松"
};

// Quick action button handler
function handleQuickAction(template) {
  const textarea = document.getElementById('user-input');
  if (textarea) {
    textarea.value = quickTemplates[template] || '';
    textarea.focus();
  }
}

// Delete a single task
async function deleteTask(taskId) {
  if (confirm('确定要删除这个任务吗？')) {
    try {
      const res = await fetch(`${API_BASE}/api/tasks/${taskId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText || `HTTP ${res.status}`);
      }
      
      // Refresh the display after deleting
      await fetchAndDisplayTasks();
    } catch (err) {
      console.error('Failed to delete task:', err);
      alert('删除失败，请稍后再试');
    }
  }
}

// Toggle task completion status
async function toggleTaskCompletion(taskId, isCompleted) {
  try {
    const res = await fetch(`${API_BASE}/api/tasks/${taskId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        status: isCompleted ? '已完成' : '待办' 
      })
    });
    
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(errText || `HTTP ${res.status}`);
    }
    
    // Refresh the display to update stats
    await fetchAndDisplayTasks();
  } catch (err) {
    console.error('Failed to toggle task completion:', err);
    alert('更新失败，请稍后再试');
  }
}

// Clear all tasks
async function clearAllTasks() {
  if (confirm('确定要清空所有任务吗？此操作不可撤销。')) {
    try {
      const res = await fetch(`${API_BASE}/api/tasks`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' }
      });
      
      if (!res.ok) {
        const errText = await res.text();
        throw new Error(errText || `HTTP ${res.status}`);
      }
      
      // Refresh the display after clearing
      await fetchAndDisplayTasks();
      alert('任务已清空');
    } catch (err) {
      console.error('Failed to clear tasks:', err);
      alert('清空失败，请稍后再试');
    }
  }
}

// Export schedule
function exportSchedule() {
  const table = document.getElementById('schedule-table');
  if (!table) return;
  
  let csv = '任务名称,开始时间,结束时间,优先级\n';
  const rows = table.querySelectorAll('tbody tr');
  
  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    if (cells.length >= 4) {
      csv += `"${cells[0].textContent}","${cells[1].textContent}","${cells[2].textContent}","${cells[3].textContent}"\n`;
    }
  });
  
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', `日程表_${new Date().toISOString().split('T')[0]}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// When DOM is ready, load tasks and set up event listeners
document.addEventListener('DOMContentLoaded', () => {
  fetchAndDisplayTasks();
  
  // Set up periodic refresh to update expired task status
  setInterval(() => {
    fetchAndDisplayTasks();
  }, 60000); // Refresh every minute

  // Submit button
  const submitBtn = document.getElementById('submit-btn');
  if (submitBtn) {
    submitBtn.addEventListener('click', (ev) => {
      ev.preventDefault();
      submitToAI();
    });
  }

  // Quick action buttons
  document.querySelectorAll('.quick-btn').forEach(btn => {
    btn.addEventListener('click', (ev) => {
      const template = ev.target.dataset.template;
      handleQuickAction(template);
    });
  });

  // Table action buttons
  const clearAllBtn = document.getElementById('clear-all-btn');
  if (clearAllBtn) {
    clearAllBtn.addEventListener('click', clearAllTasks);
  }

  const exportBtn = document.getElementById('export-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportSchedule);
  }

  const refreshBtn = document.getElementById('refresh-btn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      fetchAndDisplayTasks();
    });
  }
});